'use client';

import { useState, useEffect, useCallback } from 'react';

export interface WorkspaceData {
  teams: any[];
  spaces: any[];
  allTasks: any[];
  members: any[];
  timeEntries: any[];
  teamId: string | null;
}

const EMPTY_DATA: WorkspaceData = {
  teams: [],
  spaces: [],
  allTasks: [],
  members: [],
  timeEntries: [],
  teamId: null,
};

export function useClickUpData() {
  const [data, setData] = useState<WorkspaceData>(EMPTY_DATA);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasToken, setHasToken] = useState<boolean | null>(null);

  const checkToken = useCallback(async () => {
    try {
      const res = await fetch('/api/clickup/token');
      const json = await res.json();
      setHasToken(json?.hasToken ?? false);
      return json?.hasToken ?? false;
    } catch {
      setHasToken(false);
      return false;
    }
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/clickup/workspace');
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? 'Error al obtener datos');
      }
      const json = await res.json();
      setData({
        teams: json?.teams ?? [],
        spaces: json?.spaces ?? [],
        allTasks: json?.allTasks ?? [],
        members: json?.members ?? [],
        timeEntries: json?.timeEntries ?? [],
        teamId: json?.teamId ?? null,
      });
    } catch (e: any) {
      setError(e?.message ?? 'Error desconocido');
    } finally {
      setLoading(false);
    }
  }, []);

  const refresh = useCallback(async () => {
    // Clear cache then re-fetch
    await fetch('/api/clickup/data', { method: 'DELETE' }).catch(() => {});
    await fetchData();
  }, [fetchData]);

  useEffect(() => {
    checkToken().then((has: boolean) => {
      if (has) fetchData();
      else setLoading(false);
    });
  }, [checkToken, fetchData]);

  return { data, loading, error, hasToken, refresh, checkToken, fetchData };
}
