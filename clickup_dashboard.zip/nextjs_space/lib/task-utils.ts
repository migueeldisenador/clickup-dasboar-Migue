// Utility functions for processing ClickUp task data

export function getStatusCounts(tasks: any[]): { name: string; value: number; color: string }[] {
  const map: Record<string, { count: number; color: string }> = {};
  const statusColors: Record<string, string> = {
    'open': '#60B5FF',
    'to do': '#60B5FF',
    'in progress': '#FF9149',
    'review': '#A19AD3',
    'complete': '#80D8C3',
    'closed': '#80D8C3',
    'done': '#80D8C3',
  };
  const defaultColors = ['#7c3aed', '#ec4899', '#3b82f6', '#f97316', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'];
  let colorIdx = 0;

  for (const t of (tasks ?? [])) {
    const status = t?.status?.status?.toLowerCase?.() ?? 'sin estado';
    const statusColor = t?.status?.color ?? statusColors[status] ?? defaultColors[colorIdx % defaultColors.length];
    if (!map[status]) {
      map[status] = { count: 0, color: statusColor };
      colorIdx++;
    }
    map[status].count++;
  }
  return Object.entries(map).map(([name, { count, color }]: [string, any]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value: count,
    color,
  }));
}

export function getPriorityCounts(tasks: any[]): { name: string; value: number; color: string }[] {
  const priorityMap: Record<string, { label: string; color: string }> = {
    '1': { label: 'Urgente', color: '#ef4444' },
    '2': { label: 'Alta', color: '#f97316' },
    '3': { label: 'Normal', color: '#3b82f6' },
    '4': { label: 'Baja', color: '#6b7280' },
  };
  const counts: Record<string, number> = {};

  for (const t of (tasks ?? [])) {
    const pId = String(t?.priority?.id ?? 'none');
    const label = priorityMap[pId]?.label ?? 'Sin prioridad';
    counts[label] = (counts[label] ?? 0) + 1;
  }

  return Object.entries(counts).map(([name, value]: [string, number]) => {
    const entry = Object.values(priorityMap).find((p: any) => p.label === name);
    return { name, value, color: entry?.color ?? '#6b7280' };
  });
}

export function getAssigneeCounts(tasks: any[]): { name: string; value: number; color: string }[] {
  const colors = ['#7c3aed', '#ec4899', '#3b82f6', '#f97316', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];
  const map: Record<string, number> = {};

  for (const t of (tasks ?? [])) {
    const assignees = t?.assignees ?? [];
    if (assignees.length === 0) {
      map['Sin asignar'] = (map['Sin asignar'] ?? 0) + 1;
    } else {
      for (const a of assignees) {
        const name = a?.username ?? a?.email ?? 'Desconocido';
        map[name] = (map[name] ?? 0) + 1;
      }
    }
  }

  return Object.entries(map)
    .sort((a: any, b: any) => (b[1] ?? 0) - (a[1] ?? 0))
    .slice(0, 10)
    .map(([name, value]: [string, number], i: number) => ({
      name,
      value,
      color: colors[i % colors.length],
    }));
}

export function getOverdueTasks(tasks: any[]): any[] {
  const now = Date.now();
  return (tasks ?? []).filter((t: any) => {
    const dueDate = Number(t?.due_date);
    const status = t?.status?.status?.toLowerCase?.() ?? '';
    return dueDate > 0 && dueDate < now && !['complete', 'closed', 'done'].includes(status);
  });
}

export function getTasksBySpace(tasks: any[]): { name: string; tareas: number }[] {
  const map: Record<string, number> = {};
  for (const t of (tasks ?? [])) {
    const space = t?.spaceName ?? 'Sin espacio';
    map[space] = (map[space] ?? 0) + 1;
  }
  return Object.entries(map).map(([name, tareas]: [string, number]) => ({ name, tareas }));
}

export function getTasksByList(tasks: any[]): { name: string; tareas: number }[] {
  const map: Record<string, number> = {};
  for (const t of (tasks ?? [])) {
    const list = t?.listName ?? 'Sin lista';
    map[list] = (map[list] ?? 0) + 1;
  }
  return Object.entries(map)
    .sort((a: any, b: any) => (b[1] ?? 0) - (a[1] ?? 0))
    .slice(0, 12)
    .map(([name, tareas]: [string, number]) => ({ name, tareas }));
}

export function getCreationTrend(tasks: any[]): { dia: string; creadas: number; completadas: number }[] {
  const days: Record<string, { creadas: number; completadas: number }> = {};
  const now = Date.now();
  // Last 14 days
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now - i * 86400000);
    const key = `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
    days[key] = { creadas: 0, completadas: 0 };
  }

  for (const t of (tasks ?? [])) {
    const created = Number(t?.date_created);
    const closed = Number(t?.date_closed);
    if (created > 0) {
      const d = new Date(created);
      const key = `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
      if (days[key]) days[key].creadas++;
    }
    if (closed > 0) {
      const d = new Date(closed);
      const key = `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
      if (days[key]) days[key].completadas++;
    }
  }

  return Object.entries(days).map(([dia, vals]: [string, any]) => ({
    dia,
    creadas: vals?.creadas ?? 0,
    completadas: vals?.completadas ?? 0,
  }));
}

export function getTimeTrackingData(timeEntries: any[]): {
  totalHours: number;
  byDay: { dia: string; horas: number }[];
  byUser: { name: string; horas: number; color: string }[];
} {
  const colors = ['#7c3aed', '#ec4899', '#3b82f6', '#f97316', '#10b981', '#f59e0b'];
  let totalMs = 0;
  const dayMap: Record<string, number> = {};
  const userMap: Record<string, number> = {};

  for (const te of (timeEntries ?? [])) {
    const duration = Number(te?.duration ?? 0);
    totalMs += duration;
    const start = Number(te?.start ?? 0);
    if (start > 0) {
      const d = new Date(start);
      const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
      const key = dayNames[d.getUTCDay()] ?? 'N/A';
      dayMap[key] = (dayMap[key] ?? 0) + duration;
    }
    const userName = te?.user?.username ?? te?.user?.email ?? 'Desconocido';
    userMap[userName] = (userMap[userName] ?? 0) + duration;
  }

  const totalHours = Math.round(totalMs / 3600000 * 10) / 10;

  const orderedDays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const byDay = orderedDays.map((dia: string) => ({
    dia,
    horas: Math.round((dayMap[dia] ?? 0) / 3600000 * 10) / 10,
  }));

  const byUser = Object.entries(userMap)
    .sort((a: any, b: any) => (b[1] ?? 0) - (a[1] ?? 0))
    .map(([name, ms]: [string, number], i: number) => ({
      name,
      horas: Math.round(ms / 3600000 * 10) / 10,
      color: colors[i % colors.length],
    }));

  return { totalHours, byDay, byUser };
}

export function getCompletionRate(tasks: any[]): number {
  const total = (tasks ?? []).length;
  if (total === 0) return 0;
  const done = (tasks ?? []).filter((t: any) => {
    const s = t?.status?.status?.toLowerCase?.() ?? '';
    return ['complete', 'closed', 'done'].includes(s);
  }).length;
  return Math.round((done / total) * 100);
}
