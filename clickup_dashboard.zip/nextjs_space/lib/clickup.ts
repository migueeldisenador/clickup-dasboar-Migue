import { prisma } from '@/lib/prisma';

const CLICKUP_API = 'https://api.clickup.com/api/v2';
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

export async function getClickUpToken(userId: string): Promise<string | null> {
  const record = await prisma.clickUpToken.findUnique({ where: { userId } });
  return record?.token ?? null;
}

export async function saveClickUpToken(userId: string, token: string) {
  await prisma.clickUpToken.upsert({
    where: { userId },
    update: { token },
    create: { userId, token },
  });
}

export async function deleteClickUpToken(userId: string) {
  await prisma.clickUpToken.deleteMany({ where: { userId } });
}

async function getCachedData(userId: string, key: string): Promise<any | null> {
  try {
    const cached = await prisma.dataCache.findUnique({
      where: { userId_cacheKey: { userId, cacheKey: key } },
    });
    if (cached && new Date(cached.expiresAt) > new Date()) {
      return JSON.parse(cached.data);
    }
    return null;
  } catch {
    return null;
  }
}

async function setCachedData(userId: string, key: string, data: any) {
  try {
    const expiresAt = new Date(Date.now() + CACHE_TTL_MS);
    await prisma.dataCache.upsert({
      where: { userId_cacheKey: { userId, cacheKey: key } },
      update: { data: JSON.stringify(data), expiresAt },
      create: { userId, cacheKey: key, data: JSON.stringify(data), expiresAt },
    });
  } catch { /* ignore cache write errors */ }
}

export async function clickUpFetch(token: string, endpoint: string, userId: string): Promise<any> {
  const cacheKey = endpoint;
  const cached = await getCachedData(userId, cacheKey);
  if (cached) return cached;

  const res = await fetch(`${CLICKUP_API}${endpoint}`, {
    headers: { Authorization: token, 'Content-Type': 'application/json' },
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => 'Error desconocido');
    throw new Error(`ClickUp API error ${res.status}: ${errText}`);
  }

  const data = await res.json();
  await setCachedData(userId, cacheKey, data);
  return data;
}

export async function clearCache(userId: string) {
  await prisma.dataCache.deleteMany({ where: { userId } });
}
