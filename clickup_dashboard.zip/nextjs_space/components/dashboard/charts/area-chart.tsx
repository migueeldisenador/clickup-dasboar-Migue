'use client';

import dynamic from 'next/dynamic';
import { Loader2 } from 'lucide-react';

const AreaChartInner = dynamic(() => import('./area-chart-inner'), {
  ssr: false,
  loading: () => <div className="flex items-center justify-center h-full"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>,
});

export function AreaChartComponent(props: { data: any[]; xKey: string; lines: { key: string; color: string; name: string }[]; title: string }) {
  return <AreaChartInner {...props} />;
}
