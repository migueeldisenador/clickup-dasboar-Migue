'use client';

import dynamic from 'next/dynamic';
import { Loader2 } from 'lucide-react';

const BarChartInner = dynamic(() => import('./bar-chart-inner'), {
  ssr: false,
  loading: () => <div className="flex items-center justify-center h-full"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>,
});

export function BarChartComponent(props: { data: any[]; xKey: string; bars: { key: string; color: string; name: string }[]; title: string }) {
  return <BarChartInner {...props} />;
}
