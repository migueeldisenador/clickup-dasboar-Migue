'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface DonutChartProps {
  data: { name: string; value: number; color: string }[];
  title: string;
}

export default function DonutChartInner({ data, title }: DonutChartProps) {
  const safeData = data ?? [];
  if (safeData.length === 0) {
    return <div className="flex items-center justify-center h-full text-gray-500 text-sm">Sin datos</div>;
  }
  const total = safeData.reduce((acc: number, d: any) => acc + (d?.value ?? 0), 0);

  return (
    <div className="w-full h-full">
      <h3 className="text-sm font-semibold text-gray-300 mb-2 px-1">{title}</h3>
      <ResponsiveContainer width="100%" height="90%">
        <PieChart>
          <Pie
            data={safeData}
            cx="50%"
            cy="50%"
            innerRadius="55%"
            outerRadius="80%"
            paddingAngle={3}
            dataKey="value"
            animationDuration={1200}
          >
            {safeData.map((entry: any, idx: number) => (
              <Cell key={idx} fill={entry?.color ?? '#7c3aed'} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{ backgroundColor: '#1e2746', border: '1px solid #2a3158', borderRadius: '8px', fontSize: 11 }}
            itemStyle={{ color: '#e2e8f0' }}
            formatter={(value: any) => [`${value} (${total > 0 ? ((Number(value) / total) * 100).toFixed(1) : 0}%)`, '']}
          />
          <Legend verticalAlign="top" wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
