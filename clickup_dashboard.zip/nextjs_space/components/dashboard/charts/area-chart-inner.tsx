'use client';

import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface AreaChartProps {
  data: any[];
  xKey: string;
  lines: { key: string; color: string; name: string }[];
  title: string;
}

export default function AreaChartInner({ data, xKey, lines, title }: AreaChartProps) {
  const safeData = data ?? [];
  if (safeData.length === 0) {
    return <div className="flex items-center justify-center h-full text-gray-500 text-sm">Sin datos</div>;
  }
  return (
    <div className="w-full h-full">
      <h3 className="text-sm font-semibold text-gray-300 mb-2 px-1">{title}</h3>
      <ResponsiveContainer width="100%" height="90%">
        <AreaChart data={safeData} margin={{ top: 5, right: 10, left: 0, bottom: 20 }}>
          <defs>
            {(lines ?? []).map((line: any) => (
              <linearGradient key={line?.key} id={`grad-${line?.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={line?.color} stopOpacity={0.3} />
                <stop offset="95%" stopColor={line?.color} stopOpacity={0} />
              </linearGradient>
            ))}
          </defs>
          <XAxis dataKey={xKey} tickLine={false} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={{ stroke: '#374151' }} />
          <YAxis tickLine={false} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={{ stroke: '#374151' }} />
          <Tooltip
            contentStyle={{ backgroundColor: '#1e2746', border: '1px solid #2a3158', borderRadius: '8px', fontSize: 11 }}
            itemStyle={{ color: '#e2e8f0' }}
          />
          <Legend verticalAlign="top" wrapperStyle={{ fontSize: 11 }} />
          {(lines ?? []).map((line: any) => (
            <Area
              key={line?.key}
              type="monotone"
              dataKey={line?.key}
              stroke={line?.color}
              fill={`url(#grad-${line?.key})`}
              name={line?.name}
              strokeWidth={2}
              animationDuration={1500}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
