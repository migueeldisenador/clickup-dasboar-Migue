'use client';

import dynamic from 'next/dynamic';
import { Loader2 } from 'lucide-react';

const DonutChartInner = dynamic(() => import('./donut-chart-inner'), {
  ssr: false,
  loading: () => <div className="flex items-center justify-center h-full"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>,
});

export function DonutChart(props: { data: { name: string; value: number; color: string }[]; title: string }) {
  return <DonutChartInner {...props} />;
}
