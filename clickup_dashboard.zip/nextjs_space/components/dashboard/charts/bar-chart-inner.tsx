'use client';

import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface BarChartProps {
  data: any[];
  xKey: string;
  bars: { key: string; color: string; name: string }[];
  title: string;
}

export default function BarChartInner({ data, xKey, bars, title }: BarChartProps) {
  const safeData = data ?? [];
  if (safeData.length === 0) {
    return <div className="flex items-center justify-center h-full text-gray-500 text-sm">Sin datos</div>;
  }
  return (
    <div className="w-full h-full">
      <h3 className="text-sm font-semibold text-gray-300 mb-2 px-1">{title}</h3>
      <ResponsiveContainer width="100%" height="90%">
        <BarChart data={safeData} margin={{ top: 5, right: 10, left: 0, bottom: 20 }}>
          <XAxis
            dataKey={xKey}
            tickLine={false}
            tick={{ fontSize: 10, fill: '#9ca3af' }}
            axisLine={{ stroke: '#374151' }}
            interval="preserveStartEnd"
          />
          <YAxis
            tickLine={false}
            tick={{ fontSize: 10, fill: '#9ca3af' }}
            axisLine={{ stroke: '#374151' }}
          />
          <Tooltip
            contentStyle={{ backgroundColor: '#1e2746', border: '1px solid #2a3158', borderRadius: '8px', fontSize: 11 }}
            itemStyle={{ color: '#e2e8f0' }}
          />
          <Legend verticalAlign="top" wrapperStyle={{ fontSize: 11 }} />
          {(bars ?? []).map((bar: any) => (
            <Bar key={bar?.key} dataKey={bar?.key} fill={bar?.color} name={bar?.name} radius={[4, 4, 0, 0]} animationDuration={1200} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
