'use client';

import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { useEffect, useRef } from 'react';
import { useInView } from 'react-intersection-observer';
import { LucideIcon } from 'lucide-react';

interface KPICardProps {
  title: string;
  value: number;
  suffix?: string;
  prefix?: string;
  icon: LucideIcon;
  color: string;
  trend?: number;
  subtitle?: string;
}

function AnimatedNumber({ value, prefix, suffix }: { value: number; prefix?: string; suffix?: string }) {
  const motionVal = useMotionValue(0);
  const rounded = useTransform(motionVal, (v: number) => {
    const r = Math.round(v);
    return `${prefix ?? ''}${r.toLocaleString('es-CO')}${suffix ?? ''}`;
  });
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.3 });
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (inView && !hasAnimated.current) {
      hasAnimated.current = true;
      animate(motionVal, value, { duration: 1.5, ease: 'easeOut' });
    }
  }, [inView, value, motionVal]);

  return <motion.span ref={ref}>{rounded}</motion.span>;
}

export function KPICard({ title, value, suffix, prefix, icon: Icon, color, trend, subtitle }: KPICardProps) {
  const colorMap: Record<string, string> = {
    purple: 'from-purple-500/20 to-purple-600/5 border-purple-500/30',
    pink: 'from-pink-500/20 to-pink-600/5 border-pink-500/30',
    blue: 'from-blue-500/20 to-blue-600/5 border-blue-500/30',
    orange: 'from-orange-500/20 to-orange-600/5 border-orange-500/30',
    green: 'from-emerald-500/20 to-emerald-600/5 border-emerald-500/30',
    red: 'from-red-500/20 to-red-600/5 border-red-500/30',
  };
  const iconColorMap: Record<string, string> = {
    purple: 'text-purple-400',
    pink: 'text-pink-400',
    blue: 'text-blue-400',
    orange: 'text-orange-400',
    green: 'text-emerald-400',
    red: 'text-red-400',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={`rounded-xl bg-gradient-to-br ${colorMap[color] ?? colorMap.purple} border p-5 hover:scale-[1.02] transition-transform duration-200`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-lg bg-white/5 ${iconColorMap[color] ?? iconColorMap.purple}`}>
          <Icon className="w-5 h-5" />
        </div>
        {trend !== undefined && trend !== null && (
          <span className={`text-xs font-mono font-semibold ${(trend ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {(trend ?? 0) >= 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
      <div className="text-2xl font-display font-bold text-white">
        <AnimatedNumber value={value} prefix={prefix} suffix={suffix} />
      </div>
      <p className="text-sm text-gray-400 mt-1">{title}</p>
      {subtitle && <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>}
    </motion.div>
  );
}
