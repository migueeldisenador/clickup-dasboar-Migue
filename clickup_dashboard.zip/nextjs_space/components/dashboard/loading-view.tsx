'use client';

import { Loader2 } from 'lucide-react';

export function LoadingView() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh]">
      <Loader2 className="w-10 h-10 animate-spin text-purple-400 mb-4" />
      <p className="text-gray-400 text-sm">Cargando datos de ClickUp...</p>
    </div>
  );
}
