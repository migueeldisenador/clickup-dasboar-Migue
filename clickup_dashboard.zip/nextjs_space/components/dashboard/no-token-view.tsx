'use client';

import { Settings, Key } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export function NoTokenView() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4"
    >
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center mb-6">
        <Key className="w-10 h-10 text-purple-400" />
      </div>
      <h2 className="text-2xl font-display font-bold text-white mb-3">Configura tu API Token</h2>
      <p className="text-gray-400 max-w-md mb-6">
        Para ver tus métricas de ClickUp, necesitas configurar tu API Token personal.
        Ve a Configuración para agregarlo.
      </p>
      <Link href="/dashboard/configuracion">
        <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
          <Settings className="w-4 h-4 mr-2" />
          Ir a Configuración
        </Button>
      </Link>
    </motion.div>
  );
}
