export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getClickUpToken, clickUpFetch, clearCache } from '@/lib/clickup';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  const token = await getClickUpToken(userId);
  if (!token) return NextResponse.json({ error: 'Token de ClickUp no configurado' }, { status: 400 });

  const endpoint = req.nextUrl.searchParams.get('endpoint');
  if (!endpoint) return NextResponse.json({ error: 'Endpoint requerido' }, { status: 400 });

  // Whitelist allowed endpoints
  const allowed = ['/team', '/space', '/folder', '/list', '/task', '/time_entries', '/member', '/goal'];
  const isAllowed = allowed.some((a: string) => endpoint.includes(a) || endpoint.startsWith('/team'));
  if (!isAllowed) return NextResponse.json({ error: 'Endpoint no permitido' }, { status: 403 });

  try {
    const data = await clickUpFetch(token, endpoint, userId);
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error al obtener datos' }, { status: 500 });
  }
}

export async function DELETE() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  await clearCache(userId);
  return NextResponse.json({ success: true });
}
