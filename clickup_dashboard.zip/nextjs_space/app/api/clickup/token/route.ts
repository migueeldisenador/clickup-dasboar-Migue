export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getClickUpToken, saveClickUpToken, deleteClickUpToken } from '@/lib/clickup';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  const token = await getClickUpToken(userId);
  return NextResponse.json({ hasToken: !!token });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  const { token } = await req.json();
  if (!token) return NextResponse.json({ error: 'Token requerido' }, { status: 400 });

  // Validate token by calling ClickUp API
  try {
    const res = await fetch('https://api.clickup.com/api/v2/team', {
      headers: { Authorization: token },
    });
    if (!res.ok) {
      return NextResponse.json({ error: 'Token inválido. Verifica tu API token de ClickUp.' }, { status: 400 });
    }
  } catch {
    return NextResponse.json({ error: 'No se pudo verificar el token' }, { status: 400 });
  }

  await saveClickUpToken(userId, token);
  return NextResponse.json({ success: true });
}

export async function DELETE() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  await deleteClickUpToken(userId);
  return NextResponse.json({ success: true });
}
