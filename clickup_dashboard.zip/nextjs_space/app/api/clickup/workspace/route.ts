export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getClickUpToken, clickUpFetch } from '@/lib/clickup';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  const userId = (session.user as any).id;
  const token = await getClickUpToken(userId);
  if (!token) return NextResponse.json({ error: 'Token no configurado' }, { status: 400 });

  try {
    // Get teams/workspaces
    const teamsData = await clickUpFetch(token, '/team', userId);
    const teams = teamsData?.teams ?? [];
    if (teams.length === 0) return NextResponse.json({ teams: [], spaces: [], allTasks: [], members: [] });

    const team = teams[0];
    const teamId = team?.id;
    const members = team?.members?.map((m: any) => ({
      id: m?.user?.id,
      username: m?.user?.username,
      email: m?.user?.email,
      profilePicture: m?.user?.profilePicture,
      initials: m?.user?.initials,
      role: m?.user?.role,
    })) ?? [];

    // Get spaces
    const spacesData = await clickUpFetch(token, `/team/${teamId}/space?archived=false`, userId);
    const spaces = spacesData?.spaces ?? [];

    // Get all tasks from all spaces
    const allTasks: any[] = [];
    for (const space of spaces) {
      try {
        // Get folders
        const foldersData = await clickUpFetch(token, `/space/${space.id}/folder?archived=false`, userId);
        const folders = foldersData?.folders ?? [];
        for (const folder of folders) {
          const listsData = await clickUpFetch(token, `/folder/${folder.id}/list?archived=false`, userId);
          const lists = listsData?.lists ?? [];
          for (const list of lists) {
            try {
              const tasksData = await clickUpFetch(token, `/list/${list.id}/task?subtasks=true&include_closed=true`, userId);
              const tasks = (tasksData?.tasks ?? []).map((t: any) => ({
                ...t,
                spaceName: space?.name ?? '',
                folderName: folder?.name ?? '',
                listName: list?.name ?? '',
              }));
              allTasks.push(...tasks);
            } catch { /* skip */ }
          }
        }
        // Folderless lists
        try {
          const folderlessData = await clickUpFetch(token, `/space/${space.id}/list?archived=false`, userId);
          const folderlessLists = folderlessData?.lists ?? [];
          for (const list of folderlessLists) {
            try {
              const tasksData = await clickUpFetch(token, `/list/${list.id}/task?subtasks=true&include_closed=true`, userId);
              const tasks = (tasksData?.tasks ?? []).map((t: any) => ({
                ...t,
                spaceName: space?.name ?? '',
                folderName: '',
                listName: list?.name ?? '',
              }));
              allTasks.push(...tasks);
            } catch { /* skip */ }
          }
        } catch { /* skip */ }
      } catch { /* skip space */ }
    }

    // Get time entries
    let timeEntries: any[] = [];
    try {
      const now = Date.now();
      const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;
      const teData = await clickUpFetch(token, `/team/${teamId}/time_entries?start_date=${thirtyDaysAgo}&end_date=${now}`, userId);
      timeEntries = teData?.data ?? [];
    } catch { /* skip */ }

    return NextResponse.json({
      teams,
      spaces: spaces.map((s: any) => ({ id: s?.id, name: s?.name })),
      allTasks,
      members,
      timeEntries,
      teamId,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error al obtener datos del workspace' }, { status: 500 });
  }
}
