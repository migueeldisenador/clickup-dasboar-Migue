'use client';

import { useState, useMemo } from 'react';
import { useClickUpData } from '@/hooks/use-clickup-data';
import { NoTokenView } from '@/components/dashboard/no-token-view';
import { LoadingView } from '@/components/dashboard/loading-view';
import { ErrorView } from '@/components/dashboard/error-view';
import { DonutChart } from '@/components/dashboard/charts/donut-chart';
import { BarChartComponent } from '@/components/dashboard/charts/bar-chart';
import { getStatusCounts, getPriorityCounts, getTasksByList } from '@/lib/task-utils';
import { motion } from 'framer-motion';
import { Search, Filter, ExternalLink, AlertCircle, CheckCircle2, Clock, ArrowUpDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function TareasPage() {
  const { data, loading, error, hasToken, refresh } = useClickUpData();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'date' | 'priority' | 'name'>('date');

  const tasks = data?.allTasks ?? [];

  const statuses = useMemo(() => {
    const set = new Set<string>();
    tasks.forEach((t: any) => set.add(t?.status?.status ?? 'Sin estado'));
    return Array.from(set);
  }, [tasks]);

  const filtered = useMemo(() => {
    let result = [...tasks];
    if (search) {
      const s = search.toLowerCase();
      result = result.filter((t: any) => (t?.name ?? '').toLowerCase().includes(s));
    }
    if (statusFilter !== 'all') {
      result = result.filter((t: any) => (t?.status?.status ?? '') === statusFilter);
    }
    if (priorityFilter !== 'all') {
      result = result.filter((t: any) => String(t?.priority?.id ?? 'none') === priorityFilter);
    }
    result.sort((a: any, b: any) => {
      if (sortBy === 'date') return Number(b?.date_created ?? 0) - Number(a?.date_created ?? 0);
      if (sortBy === 'priority') return Number(a?.priority?.id ?? 5) - Number(b?.priority?.id ?? 5);
      return (a?.name ?? '').localeCompare(b?.name ?? '');
    });
    return result;
  }, [tasks, search, statusFilter, priorityFilter, sortBy]);

  if (hasToken === false) return <NoTokenView />;
  if (loading) return <LoadingView />;
  if (error) return <ErrorView error={error} onRetry={refresh} />;

  const statusData = getStatusCounts(tasks);
  const priorityData = getPriorityCounts(tasks);
  const listData = getTasksByList(tasks);

  const priorityColors: Record<string, string> = { '1': 'bg-red-500', '2': 'bg-orange-500', '3': 'bg-blue-500', '4': 'bg-gray-500' };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Tareas</h1>
        <p className="text-gray-400 text-sm mt-1">Detalle de todas las tareas del workspace</p>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-xl p-4 h-[280px]">
          <DonutChart data={statusData} title="Por Estado" />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-xl p-4 h-[280px]">
          <DonutChart data={priorityData} title="Por Prioridad" />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-xl p-4 h-[280px]">
          <BarChartComponent data={listData} xKey="name" bars={[{ key: 'tareas', color: '#7c3aed', name: 'Tareas' }]} title="Top Listas" />
        </motion.div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Buscar tareas..."
            value={search}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value)}
            className="pl-9 bg-[#1e2746] border-[#2a3158] text-white placeholder:text-gray-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#1e2746] border border-[#2a3158] text-gray-300 text-sm"
        >
          <option value="all">Todos los estados</option>
          {statuses.map((s: string) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select
          value={priorityFilter}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setPriorityFilter(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#1e2746] border border-[#2a3158] text-gray-300 text-sm"
        >
          <option value="all">Todas las prioridades</option>
          <option value="1">Urgente</option>
          <option value="2">Alta</option>
          <option value="3">Normal</option>
          <option value="4">Baja</option>
        </select>
        <button
          onClick={() => setSortBy(sortBy === 'date' ? 'priority' : sortBy === 'priority' ? 'name' : 'date')}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#1e2746] border border-[#2a3158] text-gray-300 text-sm hover:bg-[#252f50]"
        >
          <ArrowUpDown className="w-4 h-4" />
          {sortBy === 'date' ? 'Fecha' : sortBy === 'priority' ? 'Prioridad' : 'Nombre'}
        </button>
      </div>

      {/* Task List */}
      <div className="space-y-2">
        <p className="text-xs text-gray-500">{filtered.length} tareas encontradas</p>
        {filtered.length === 0 && (
          <div className="glass-card rounded-xl p-8 text-center">
            <Filter className="w-8 h-8 text-gray-500 mx-auto mb-2" />
            <p className="text-gray-400">No se encontraron tareas con los filtros seleccionados</p>
          </div>
        )}
        <div className="space-y-1.5 max-h-[600px] overflow-y-auto pr-1">
          {filtered.slice(0, 100).map((t: any) => {
            const isOverdue = Number(t?.due_date ?? 0) > 0 && Number(t?.due_date) < Date.now() && !['complete','closed','done'].includes(t?.status?.status?.toLowerCase?.() ?? '');
            const isDone = ['complete','closed','done'].includes(t?.status?.status?.toLowerCase?.() ?? '');
            return (
              <motion.div
                key={t?.id ?? Math.random()}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-card rounded-lg px-4 py-3 flex items-center gap-3 group hover:bg-white/5 transition-all"
              >
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${priorityColors[String(t?.priority?.id)] ?? 'bg-gray-600'}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate">{t?.name ?? 'Sin nombre'}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-gray-500">{t?.listName ?? ''}</span>
                    {t?.assignees?.[0] && <span className="text-xs text-gray-500">• {t.assignees[0]?.username ?? ''}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {isOverdue && (
                    <Badge variant="destructive" className="text-xs"><AlertCircle className="w-3 h-3 mr-1" />Vencida</Badge>
                  )}
                  {isDone && (
                    <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs"><CheckCircle2 className="w-3 h-3 mr-1" />Hecha</Badge>
                  )}
                  <Badge variant="outline" className="text-xs border-[#2a3158] text-gray-400">
                    {t?.status?.status ?? 'N/A'}
                  </Badge>
                  {t?.url && (
                    <a href={t.url} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-purple-400">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
        {filtered.length > 100 && <p className="text-xs text-gray-500 text-center">Mostrando las primeras 100 tareas</p>}
      </div>
    </div>
  );
}
