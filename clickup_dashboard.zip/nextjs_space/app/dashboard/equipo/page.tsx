'use client';

import { useClickUpData } from '@/hooks/use-clickup-data';
import { KPICard } from '@/components/dashboard/kpi-card';
import { BarChartComponent } from '@/components/dashboard/charts/bar-chart';
import { DonutChart } from '@/components/dashboard/charts/donut-chart';
import { NoTokenView } from '@/components/dashboard/no-token-view';
import { LoadingView } from '@/components/dashboard/loading-view';
import { ErrorView } from '@/components/dashboard/error-view';
import { getAssigneeCounts, getTimeTrackingData } from '@/lib/task-utils';
import { Users, UserCheck, CheckSquare, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useMemo } from 'react';

export default function EquipoPage() {
  const { data, loading, error, hasToken, refresh } = useClickUpData();

  const tasks = data?.allTasks ?? [];
  const members = data?.members ?? [];
  const timeData = useMemo(() => getTimeTrackingData(data?.timeEntries ?? []), [data?.timeEntries]);
  const assigneeData = useMemo(() => getAssigneeCounts(tasks), [tasks]);

  const memberStats = useMemo(() => {
    const stats: Record<string, { total: number; done: number; inProgress: number; overdue: number }> = {};
    for (const t of tasks) {
      const assignees = t?.assignees ?? [];
      for (const a of assignees) {
        const name = a?.username ?? a?.email ?? 'Desconocido';
        if (!stats[name]) stats[name] = { total: 0, done: 0, inProgress: 0, overdue: 0 };
        stats[name].total++;
        const status = t?.status?.status?.toLowerCase?.() ?? '';
        if (['complete', 'closed', 'done'].includes(status)) stats[name].done++;
        if (status === 'in progress') stats[name].inProgress++;
        const dueDate = Number(t?.due_date ?? 0);
        if (dueDate > 0 && dueDate < Date.now() && !['complete', 'closed', 'done'].includes(status)) {
          stats[name].overdue++;
        }
      }
    }
    return Object.entries(stats)
      .sort((a: any, b: any) => (b[1]?.total ?? 0) - (a[1]?.total ?? 0))
      .map(([name, s]: [string, any]) => ({
        name,
        total: s?.total ?? 0,
        completadas: s?.done ?? 0,
        enProgreso: s?.inProgress ?? 0,
        vencidas: s?.overdue ?? 0,
        tasa: s?.total > 0 ? Math.round((s.done / s.total) * 100) : 0,
      }));
  }, [tasks]);

  if (hasToken === false) return <NoTokenView />;
  if (loading) return <LoadingView />;
  if (error) return <ErrorView error={error} onRetry={refresh} />;

  const activeMembers = memberStats.filter((m: any) => (m?.total ?? 0) > 0).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Equipo</h1>
        <p className="text-gray-400 text-sm mt-1">Rendimiento y productividad del equipo</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Miembros Totales" value={members.length} icon={Users} color="purple" />
        <KPICard title="Miembros Activos" value={activeMembers} icon={UserCheck} color="green" />
        <KPICard title="Tareas Asignadas" value={tasks.filter((t: any) => (t?.assignees?.length ?? 0) > 0).length} icon={CheckSquare} color="blue" />
        <KPICard title="Horas Totales" value={timeData.totalHours} icon={Clock} color="orange" suffix="h" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-xl p-4 h-[320px]">
          <BarChartComponent
            data={memberStats.slice(0, 10)}
            xKey="name"
            bars={[
              { key: 'completadas', color: '#10b981', name: 'Completadas' },
              { key: 'enProgreso', color: '#3b82f6', name: 'En Progreso' },
              { key: 'vencidas', color: '#ef4444', name: 'Vencidas' },
            ]}
            title="Tareas por Miembro"
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-xl p-4 h-[320px]">
          <DonutChart data={assigneeData} title="Distribución de Carga" />
        </motion.div>
      </div>

      {/* Member table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#2a3158]">
          <h3 className="text-sm font-semibold text-gray-300">Detalle por Miembro</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-[#1e2746]">
                <th className="px-4 py-3 font-medium">Miembro</th>
                <th className="px-4 py-3 font-medium text-center">Total</th>
                <th className="px-4 py-3 font-medium text-center">Completadas</th>
                <th className="px-4 py-3 font-medium text-center">En Progreso</th>
                <th className="px-4 py-3 font-medium text-center">Vencidas</th>
                <th className="px-4 py-3 font-medium text-center">Tasa</th>
              </tr>
            </thead>
            <tbody>
              {memberStats.map((m: any, i: number) => (
                <tr key={i} className="border-b border-[#1e2746]/50 hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3 text-white font-medium">{m?.name ?? ''}</td>
                  <td className="px-4 py-3 text-center text-gray-300 font-mono">{m?.total ?? 0}</td>
                  <td className="px-4 py-3 text-center text-emerald-400 font-mono">{m?.completadas ?? 0}</td>
                  <td className="px-4 py-3 text-center text-blue-400 font-mono">{m?.enProgreso ?? 0}</td>
                  <td className="px-4 py-3 text-center text-red-400 font-mono">{m?.vencidas ?? 0}</td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-16 h-1.5 rounded-full bg-gray-700 overflow-hidden">
                        <div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${m?.tasa ?? 0}%` }} />
                      </div>
                      <span className="text-gray-300 font-mono text-xs">{m?.tasa ?? 0}%</span>
                    </div>
                  </td>
                </tr>
              ))}
              {memberStats.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-gray-500">No hay datos de miembros</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
