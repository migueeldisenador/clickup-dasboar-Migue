'use client';

import { useState, useEffect } from 'react';
import { Key, Save, Trash2, Loader2, CheckCircle2, ExternalLink, Shield, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function ConfiguracionPage() {
  const [token, setToken] = useState('');
  const [hasToken, setHasToken] = useState<boolean | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetch('/api/clickup/token')
      .then((r: Response) => r.json())
      .then((d: any) => setHasToken(d?.hasToken ?? false))
      .catch(() => setHasToken(false));
  }, []);

  const handleSave = async () => {
    if (!token.trim()) {
      toast.error('Ingresa tu API token');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/clickup/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        setHasToken(true);
        setToken('');
        toast.success('Token guardado correctamente');
      } else {
        toast.error(data?.error ?? 'Error al guardar el token');
      }
    } catch {
      toast.error('Error de conexión');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await fetch('/api/clickup/token', { method: 'DELETE' });
      setHasToken(false);
      toast.success('Token eliminado');
    } catch {
      toast.error('Error al eliminar el token');
    } finally {
      setDeleting(false);
    }
  };

  const handleClearCache = async () => {
    try {
      await fetch('/api/clickup/data', { method: 'DELETE' });
      toast.success('Caché limpiado. Los datos se recargarán en la próxima vista.');
    } catch {
      toast.error('Error al limpiar caché');
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Configuración</h1>
        <p className="text-gray-400 text-sm mt-1">Configura tu conexión con ClickUp</p>
      </div>

      {/* Token config card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-purple-500/20">
            <Key className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">API Token de ClickUp</h2>
            <p className="text-sm text-gray-400">Tu token personal para acceder a los datos</p>
          </div>
        </div>

        {hasToken && (
          <div className="mb-6 flex items-center gap-2 px-4 py-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <p className="text-sm text-emerald-300">Token configurado y validado</p>
          </div>
        )}

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-gray-300">{hasToken ? 'Actualizar Token' : 'API Token'}</Label>
            <Input
              type="password"
              value={token}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setToken(e.target.value)}
              placeholder="pk_XXXXXXXX..."
              className="bg-[#1e2746] border-[#2a3158] text-white placeholder:text-gray-500 font-mono"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              Guardar Token
            </Button>
            {hasToken && (
              <Button
                onClick={handleDelete}
                disabled={deleting}
                variant="outline"
                className="border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Eliminar
              </Button>
            )}
          </div>
        </div>
      </motion.div>

      {/* Instructions */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Cómo obtener tu API Token</h3>
        <ol className="space-y-3 text-sm text-gray-400">
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">1</span>
            <span>Inicia sesión en tu cuenta de ClickUp</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">2</span>
            <span>Ve a tu avatar (esquina inferior izquierda) &rarr; <strong className="text-white">Settings</strong></span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">3</span>
            <span>En el menú lateral, busca <strong className="text-white">Apps</strong></span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">4</span>
            <span>Haz clic en <strong className="text-white">Generate</strong> para crear un API Token personal</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">5</span>
            <span>Copia el token y pégalo arriba</span>
          </li>
        </ol>
        <a
          href="https://app.clickup.com/settings/apps"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 mt-4 text-sm text-purple-400 hover:text-purple-300"
        >
          <ExternalLink className="w-4 h-4" />
          Ir a ClickUp Settings
        </a>
      </motion.div>

      {/* Security info */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-5 h-5 text-emerald-400" />
          <h3 className="text-lg font-semibold text-white">Seguridad</h3>
        </div>
        <ul className="space-y-2 text-sm text-gray-400">
          <li>• Tu token se almacena de forma encriptada en nuestra base de datos</li>
          <li>• Nunca se expone al navegador ni a terceros</li>
          <li>• Todas las peticiones a ClickUp se hacen desde el servidor</li>
          <li>• Los datos se cachean por 5 minutos para optimizar rendimiento</li>
          <li>• Puedes eliminar tu token en cualquier momento</li>
        </ul>
      </motion.div>

      {/* Cache management */}
      {hasToken && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Gestión de Caché</h3>
          <p className="text-sm text-gray-400 mb-4">Los datos se cachean 5 minutos para no exceder los límites de la API.</p>
          <Button
            onClick={handleClearCache}
            variant="outline"
            className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Limpiar Caché
          </Button>
        </motion.div>
      )}
    </div>
  );
}
