'use client';

import { useClickUpData } from '@/hooks/use-clickup-data';
import { KPICard } from '@/components/dashboard/kpi-card';
import { BarChartComponent } from '@/components/dashboard/charts/bar-chart';
import { AreaChartComponent } from '@/components/dashboard/charts/area-chart';
import { DonutChart } from '@/components/dashboard/charts/donut-chart';
import { NoTokenView } from '@/components/dashboard/no-token-view';
import { LoadingView } from '@/components/dashboard/loading-view';
import { ErrorView } from '@/components/dashboard/error-view';
import { getTimeTrackingData } from '@/lib/task-utils';
import { Clock, Timer, TrendingUp, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { useMemo } from 'react';

export default function TiempoPage() {
  const { data, loading, error, hasToken, refresh } = useClickUpData();

  const timeEntries = data?.timeEntries ?? [];
  const timeData = useMemo(() => getTimeTrackingData(timeEntries), [timeEntries]);

  const dailyTrend = useMemo(() => {
    const dayMap: Record<string, number> = {};
    for (const te of timeEntries) {
      const start = Number(te?.start ?? 0);
      if (start > 0) {
        const d = new Date(start);
        const key = `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
        dayMap[key] = (dayMap[key] ?? 0) + Number(te?.duration ?? 0);
      }
    }
    return Object.entries(dayMap)
      .sort((a: any, b: any) => {
        const [am, ad] = a[0].split('/');
        const [bm, bd] = b[0].split('/');
        return (Number(am) * 100 + Number(ad)) - (Number(bm) * 100 + Number(bd));
      })
      .slice(-14)
      .map(([dia, ms]: [string, number]) => ({ dia, horas: Math.round(ms / 3600000 * 10) / 10 }));
  }, [timeEntries]);

  const avgHoursPerDay = timeData.totalHours > 0 && dailyTrend.length > 0
    ? Math.round((timeData.totalHours / dailyTrend.length) * 10) / 10
    : 0;

  if (hasToken === false) return <NoTokenView />;
  if (loading) return <LoadingView />;
  if (error) return <ErrorView error={error} onRetry={refresh} />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Seguimiento de Tiempo</h1>
        <p className="text-gray-400 text-sm mt-1">Análisis del tiempo registrado en los últimos 30 días</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Horas" value={timeData.totalHours} icon={Clock} color="purple" suffix="h" />
        <KPICard title="Registros" value={timeEntries.length} icon={Timer} color="pink" />
        <KPICard title="Promedio/Día" value={avgHoursPerDay} icon={TrendingUp} color="blue" suffix="h" />
        <KPICard title="Usuarios Activos" value={timeData.byUser.length} icon={Users} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-xl p-4 h-[320px]">
          <AreaChartComponent
            data={dailyTrend}
            xKey="dia"
            lines={[{ key: 'horas', color: '#7c3aed', name: 'Horas' }]}
            title="Tendencia Diaria"
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-xl p-4 h-[320px]">
          <BarChartComponent
            data={timeData.byDay}
            xKey="dia"
            bars={[{ key: 'horas', color: '#f97316', name: 'Horas' }]}
            title="Horas por Día de Semana"
          />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card rounded-xl p-4 h-[320px]">
          <BarChartComponent
            data={timeData.byUser}
            xKey="name"
            bars={[{ key: 'horas', color: '#ec4899', name: 'Horas' }]}
            title="Tiempo por Usuario"
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card rounded-xl p-4 h-[320px]">
          <DonutChart
            data={timeData.byUser.map((u: any) => ({ name: u?.name ?? '', value: u?.horas ?? 0, color: u?.color ?? '#7c3aed' }))}
            title="Distribución por Usuario"
          />
        </motion.div>
      </div>

      {timeEntries.length === 0 && (
        <div className="glass-card rounded-xl p-8 text-center">
          <Clock className="w-10 h-10 text-gray-500 mx-auto mb-3" />
          <p className="text-gray-400">No hay registros de tiempo en los últimos 30 días</p>
        </div>
      )}
    </div>
  );
}
