'use client';

import { useClickUpData } from '@/hooks/use-clickup-data';
import { KPICard } from '@/components/dashboard/kpi-card';
import { DonutChart } from '@/components/dashboard/charts/donut-chart';
import { BarChartComponent } from '@/components/dashboard/charts/bar-chart';
import { AreaChartComponent } from '@/components/dashboard/charts/area-chart';
import { NoTokenView } from '@/components/dashboard/no-token-view';
import { LoadingView } from '@/components/dashboard/loading-view';
import { ErrorView } from '@/components/dashboard/error-view';
import {
  getStatusCounts, getPriorityCounts, getAssigneeCounts,
  getOverdueTasks, getTasksBySpace, getCreationTrend,
  getTimeTrackingData, getCompletionRate
} from '@/lib/task-utils';
import { CheckSquare, Clock, AlertTriangle, TrendingUp, Users, RefreshCw, FolderKanban } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export default function DashboardOverview() {
  const { data, loading, error, hasToken, refresh } = useClickUpData();

  if (hasToken === false) return <NoTokenView />;
  if (loading) return <LoadingView />;
  if (error) return <ErrorView error={error} onRetry={refresh} />;

  const tasks = data?.allTasks ?? [];
  const overdue = getOverdueTasks(tasks);
  const statusData = getStatusCounts(tasks);
  const priorityData = getPriorityCounts(tasks);
  const assigneeData = getAssigneeCounts(tasks);
  const spaceData = getTasksBySpace(tasks);
  const trendData = getCreationTrend(tasks);
  const timeData = getTimeTrackingData(data?.timeEntries ?? []);
  const completionRate = getCompletionRate(tasks);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Resumen General</h1>
          <p className="text-gray-400 text-sm mt-1">Vista general de tu workspace de ClickUp</p>
        </div>
        <Button
          onClick={refresh}
          variant="outline"
          className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Actualizar
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KPICard title="Total Tareas" value={tasks.length} icon={CheckSquare} color="purple" />
        <KPICard title="Completadas" value={tasks.filter((t: any) => ['complete','closed','done'].includes(t?.status?.status?.toLowerCase?.() ?? '')).length} icon={TrendingUp} color="green" suffix="" />
        <KPICard title="En Progreso" value={tasks.filter((t: any) => (t?.status?.status?.toLowerCase?.() ?? '') === 'in progress').length} icon={Clock} color="blue" />
        <KPICard title="Vencidas" value={overdue.length} icon={AlertTriangle} color="red" />
        <KPICard title="Miembros" value={(data?.members ?? []).length} icon={Users} color="pink" />
        <KPICard title="Completado" value={completionRate} suffix="%" icon={TrendingUp} color="green" />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="glass-card rounded-xl p-4 h-[300px]"
        >
          <DonutChart data={statusData} title="Tareas por Estado" />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="glass-card rounded-xl p-4 h-[300px]"
        >
          <DonutChart data={priorityData} title="Tareas por Prioridad" />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="glass-card rounded-xl p-4 h-[300px]"
        >
          <BarChartComponent
            data={assigneeData}
            xKey="name"
            bars={[{ key: 'value', color: '#7c3aed', name: 'Tareas' }]}
            title="Top Asignados"
          />
        </motion.div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="glass-card rounded-xl p-4 h-[320px]"
        >
          <AreaChartComponent
            data={trendData}
            xKey="dia"
            lines={[
              { key: 'creadas', color: '#ec4899', name: 'Creadas' },
              { key: 'completadas', color: '#10b981', name: 'Completadas' },
            ]}
            title="Tendencia de Tareas (14 días)"
          />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="glass-card rounded-xl p-4 h-[320px]"
        >
          <BarChartComponent
            data={spaceData}
            xKey="name"
            bars={[{ key: 'tareas', color: '#3b82f6', name: 'Tareas' }]}
            title="Tareas por Espacio"
          />
        </motion.div>
      </div>

      {/* Time tracking row */}
      {timeData.totalHours > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
            className="glass-card rounded-xl p-4 h-[300px]"
          >
            <BarChartComponent
              data={timeData.byDay}
              xKey="dia"
              bars={[{ key: 'horas', color: '#f97316', name: 'Horas' }]}
              title="Tiempo por Día de Semana"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}
            className="glass-card rounded-xl p-4 h-[300px]"
          >
            <BarChartComponent
              data={timeData.byUser}
              xKey="name"
              bars={[{ key: 'horas', color: '#ec4899', name: 'Horas' }]}
              title="Tiempo por Usuario"
            />
          </motion.div>
        </div>
      )}
    </div>
  );
}
