'use client';

import { useClickUpData } from '@/hooks/use-clickup-data';
import { KPICard } from '@/components/dashboard/kpi-card';
import { BarChartComponent } from '@/components/dashboard/charts/bar-chart';
import { DonutChart } from '@/components/dashboard/charts/donut-chart';
import { NoTokenView } from '@/components/dashboard/no-token-view';
import { LoadingView } from '@/components/dashboard/loading-view';
import { ErrorView } from '@/components/dashboard/error-view';
import { FolderKanban, Layers, ListTodo, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useMemo } from 'react';

export default function ProyectosPage() {
  const { data, loading, error, hasToken, refresh } = useClickUpData();

  const tasks = data?.allTasks ?? [];
  const spaces = data?.spaces ?? [];

  const spaceStats = useMemo(() => {
    const map: Record<string, { total: number; done: number; inProgress: number }> = {};
    for (const t of tasks) {
      const space = t?.spaceName ?? 'Sin espacio';
      if (!map[space]) map[space] = { total: 0, done: 0, inProgress: 0 };
      map[space].total++;
      const status = t?.status?.status?.toLowerCase?.() ?? '';
      if (['complete', 'closed', 'done'].includes(status)) map[space].done++;
      if (status === 'in progress') map[space].inProgress++;
    }
    return Object.entries(map)
      .sort((a: any, b: any) => (b[1]?.total ?? 0) - (a[1]?.total ?? 0))
      .map(([name, s]: [string, any]) => ({
        name,
        total: s?.total ?? 0,
        completadas: s?.done ?? 0,
        enProgreso: s?.inProgress ?? 0,
        tasa: s?.total > 0 ? Math.round((s.done / s.total) * 100) : 0,
      }));
  }, [tasks]);

  const folderStats = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of tasks) {
      const folder = t?.folderName || t?.listName || 'Sin folder';
      map[folder] = (map[folder] ?? 0) + 1;
    }
    const colors = ['#7c3aed', '#ec4899', '#3b82f6', '#f97316', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];
    return Object.entries(map)
      .sort((a: any, b: any) => (b[1] ?? 0) - (a[1] ?? 0))
      .slice(0, 8)
      .map(([name, value]: [string, number], i: number) => ({ name, value, color: colors[i % colors.length] }));
  }, [tasks]);

  const uniqueLists = useMemo(() => {
    const set = new Set<string>();
    for (const t of tasks) {
      if (t?.listName) set.add(t.listName);
    }
    return set.size;
  }, [tasks]);

  if (hasToken === false) return <NoTokenView />;
  if (loading) return <LoadingView />;
  if (error) return <ErrorView error={error} onRetry={refresh} />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-display font-bold text-white tracking-tight">Proyectos</h1>
        <p className="text-gray-400 text-sm mt-1">Espacios, folders y listas de tu workspace</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Espacios" value={spaces.length} icon={FolderKanban} color="purple" />
        <KPICard title="Listas" value={uniqueLists} icon={ListTodo} color="blue" />
        <KPICard title="Total Tareas" value={tasks.length} icon={Layers} color="pink" />
        <KPICard title="Completadas" value={tasks.filter((t: any) => ['complete','closed','done'].includes(t?.status?.status?.toLowerCase?.() ?? '')).length} icon={CheckCircle2} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-xl p-4 h-[320px]">
          <BarChartComponent
            data={spaceStats}
            xKey="name"
            bars={[
              { key: 'completadas', color: '#10b981', name: 'Completadas' },
              { key: 'enProgreso', color: '#3b82f6', name: 'En Progreso' },
            ]}
            title="Tareas por Espacio"
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card rounded-xl p-4 h-[320px]">
          <DonutChart data={folderStats} title="Distribución por Folder/Lista" />
        </motion.div>
      </div>

      {/* Space cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {spaceStats.map((space: any, i: number) => (
          <motion.div
            key={space?.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i }}
            className="glass-card rounded-xl p-5 hover:scale-[1.02] transition-transform"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <FolderKanban className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">{space?.name ?? ''}</h3>
                <p className="text-xs text-gray-500">{space?.total ?? 0} tareas</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Progreso</span>
                <span className="text-white font-mono">{space?.tasa ?? 0}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-gray-700 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-700"
                  style={{ width: `${space?.tasa ?? 0}%` }}
                />
              </div>
              <div className="flex gap-4 mt-2">
                <span className="text-xs text-emerald-400">✓ {space?.completadas ?? 0}</span>
                <span className="text-xs text-blue-400">▶ {space?.enProgreso ?? 0}</span>
                <span className="text-xs text-gray-500">○ {(space?.total ?? 0) - (space?.completadas ?? 0) - (space?.enProgreso ?? 0)}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
